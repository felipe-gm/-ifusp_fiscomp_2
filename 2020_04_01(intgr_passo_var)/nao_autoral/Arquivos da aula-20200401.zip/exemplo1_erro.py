# O oscilador harmônico amortecido investigado através
# do método adaptativo do tamanho do passo
from math import sin,cos,exp,sqrt,log
from numpy import arange,array
import matplotlib.pyplot as plt

# Parâmetros da exibição dos gráficos
plt.rcParams['xtick.labelsize'] = 24
plt.rcParams['ytick.labelsize'] = 24
plt.rcParams['axes.labelsize'] = 28

# Constantes
m = 1.0     # massa do oscilador
rho = 0.4   # parâmetro de amortecimento
prec = 1e-4 # precisão exigida da solução por unidade de t

# Lista de valores da constante de mola, para variar a frequência natural
# de oscilação do sistema. Vamos usar potências de 4.
k_lista = list(map(lambda x:pow(4.0,x),[0,1,2,3,4,5,6]))

# Condições iniciais
x0, v0 = 1.0, 0.0

def f(r,t):
    x, v = r[0], r[1]
    f0, f1 = v, -(k*x + rho*v)/m
    return array([f0,f1],float)

def passo_rk4(f,r,t,h):             # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0

def passo_adaptativo(f,r,t,h,prec): # Passo adaptativo com base em RK4
    razao = 1.0 + 1e-10             # Começamos com uma razão igual a 1
    while razao >= 1.0 + 1e-10:     # Laço até que a razão seja menor que 1
        h /= razao                              # Ajustamos o tamanho do passo
        dr21 = passo_rk4(f,r,t,h)               # Um passo de tamanho h
        dr2 = dr21 + passo_rk4(f,r+dr21,t+h,h)  # Dois passos de tamanho h
        dr1 = passo_rk4(f,r,t,2*h)              # Um só passo de tamanho 2h
        epsilon = (dr2 - dr1)/30
        erro = abs(epsilon[0])                  # Erro estimado em um passo h
        razao = (erro/(h*prec))**0.25                    
    h_prox = min(h/(razao+1e-10),2*h)           # Limitando o aumento do passo
    return dr21, h, h_prox      # Retorna o incremento de r e os tamanhos
                                # do passo atual e do próximo passo

def sol_exata(t,t0):            # Supondo amortecimento subcrítico
    return exp(-gama*(t-t0)/2)*(alfa*cos(omega*(t-t0))+beta*sin(omega*(t-t0)))                                
        
a = 0.0           # Início do intervalo
b = 10.0          # Final do intervalo
h_inicial = 1e-2  # Tamanho do passo de tempo inicial

erro_medio_ada = []  # Erro médio do método adaptativo
erro_medio_rk4 = []  # Erro médio do método RK4
for k in k_lista:
    gama = rho/m
    omega = sqrt(k/m - (gama/2)**2)
    alfa, beta = x0, (v0 + gama*x0/2)/omega

    # Calculando o erro médio pelo método adaptativo
    h = h_inicial
    r = array([x0,v0],float)
    t = a
    erro_acum = 0.0
    t_lista = []
    while t<=b:
        t_lista.append(t)
        erro_acum += (r[0] - sol_exata(t,a))**2
        dr, h_atual, h_prox = passo_adaptativo(f,r,t,h,prec)
        t, r = t + h_atual, r + dr
        h = h_prox

    erro_acum /= len(t_lista)
    erro_medio_ada.append(sqrt(erro_acum))

    # Calculando o erro médio pelo método RK4
    h = h_inicial
    r = array([x0,v0],float)
    t = a
    erro_acum = 0.0
    t_lista = []
    while t<=b:
        t_lista.append(t)
        erro_acum += (r[0] - sol_exata(t,a))**2
        t, r = t + h, r + passo_rk4(f,r,t,h)

    erro_acum /= len(t_lista)
    erro_medio_rk4.append(sqrt(erro_acum))

plt.figure(figsize=(12,9))
plt.loglog(k_lista,erro_medio_ada,'ro',k_lista,erro_medio_rk4,'gs')
plt.xlabel("k")
plt.ylabel("Erro médio")
plt.show()

