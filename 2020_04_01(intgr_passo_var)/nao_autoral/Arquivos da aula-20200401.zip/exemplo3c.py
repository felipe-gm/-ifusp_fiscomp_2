# Órbita de um cometa (Newman exercício 8.10)
from math import sin,cos,exp,sqrt,log
from numpy import arange,array
from vpython import sphere,vector,color,rate,textures,local_light,\
     scene,attach_trail

scene.lights = [] # Removendo todas as luzes da cena
scene.width = 1000 # Ajustando a largura da cena
scene.height = 800 # Ajustando a altura da cena
Sol = sphere(color=color.yellow,radius=1e11) # Esfera para representar o Sol
Sol.emissive = True
sol = local_light(pos=vector(0,0,0),color=color.white) # Luz

# Constantes
M = 1.989e30     # massa do Sol
G = 6.674e-11    # constante gravitacional

# Condições iniciais
x_0, vx_0, y_0, vy_0 = 4.0e12, 0.0, 0.0, 5.0e2
scene.center = vector(0.49*x_0,0,0)
cometa = sphere(color=color.gray(0.5),radius=3e10,pos=vector(x_0,y_0,0))

GM = G*M
def f(r,t):
    x, vx, y, vy = r[0], r[1], r[2], r[3]
    GMr3 = GM/(x**2+y**2)**1.5
    f0, f1, f2, f3 = vx, -GMr3*x, vy, -GMr3*y
    return array([f0,f1,f2,f3],float)

def passo_rk4(f,r,t,h):             # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0 

dia = 24*3600.       # Duração do dia em segundos
a = 0.0              # Início do intervalo de t (em segundos)
b = 20*49*365*dia    # Final do intervalo (em segundos); per. aprox. 49a
h = dia/24           # Tamanho do passo de tempo inicial (em segundos)

r = array([x_0,vx_0,y_0,vy_0],float)

t = a
while t<=b:
    rate(100000)
    cometa.pos=vector(r[0],r[2],0)
    r += passo_rk4(f,r,t,h)
    t += h

