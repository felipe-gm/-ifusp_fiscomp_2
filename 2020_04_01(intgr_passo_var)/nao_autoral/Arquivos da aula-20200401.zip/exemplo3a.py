# Órbita de um cometa (Newman exercício 8.10)
from math import sin,cos,exp,sqrt,log
from numpy import arange,array
import matplotlib.pyplot as plt
import time

tempo_inicial = time.time()
# Parâmetros da exibição dos gráficos
plt.rcParams['xtick.labelsize'] = 24
plt.rcParams['ytick.labelsize'] = 24
plt.rcParams['axes.labelsize'] = 28

# Constantes
M = 1.989e30     # massa do Sol
G = 6.674e-11    # constante gravitacional

# Condições iniciais
x_0, vx_0, y_0, vy_0 = 4.0e12, 0.0, 0.0, 5.0e2

GM = G*M
def f(r,t):
    x, vx, y, vy = r[0], r[1], r[2], r[3]
    GMr3 = GM/(x**2+y**2)**1.5
    f0, f1, f2, f3 = vx, -GMr3*x, vy, -GMr3*y
    return array([f0,f1,f2,f3],float)

def passo_rk4(f,r,t,h):             # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0
        
a = 0.0              # Início do intervalo de t (em segundos)
b = 2.1*49*365*24*3600.  # Final do intervalo (em segundos); per. aprox. 49a
h = 3600          # Tamanho do passo de tempo (em segundos)

t_lista, x_lista, y_lista = [], [], []
r = array([x_0,vx_0,y_0,vy_0],float)
t = a
while t<=b:
    t_lista.append(t)
    x_lista.append(r[0])
    y_lista.append(r[2])
    r += passo_rk4(f,r,t,h)
    t += h

print("Tempo de execução (em segundos):",(time.time() - tempo_inicial))

plt.figure(figsize=(12,9))
plt.plot(x_lista,y_lista)
plt.xlabel("x(t)")
plt.ylabel("y(t)")
plt.show()

