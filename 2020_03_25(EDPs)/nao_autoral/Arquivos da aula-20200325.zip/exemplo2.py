from math import sin,cos,pi,sqrt
from numpy import arange,array
import matplotlib.pyplot as plt

# Parâmetros da exibição dos gráficos
plt.rcParams['xtick.labelsize'] = 24
plt.rcParams['ytick.labelsize'] = 24
plt.rcParams['axes.labelsize'] = 28

g = 9.8     # Aceleração da gravidade
L = 1.0     # Comprimento do fio

theta_0 = 170*pi/180   # Ângulo inicial
omega_0 = 0.0        # Velocidade angular inicial 

def f(r,t):
    theta, omega = r[0], r[1]
    f0, f1 = omega, -g/L * sin(theta)
    return array([f0,f1],float)

def passo_rk4(f,r,t,h):            # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0

a = 0.0           # Início do intervalo da variável independente
b = 10.0          # Final do intervalo da variável independente
N = 1000          # Número de passos da integração numérica
h = (b-a)/N       # Tamanho de um passo dessa solução

t_rk4 = arange(a,b,h)
theta_rk4, omega_rk4 = [], []

r_0 = array([theta_0,omega_0],float)          # Condição inicial, ou seja, r(a)
r = r_0
for t in t_rk4:   # Realizando a integração numérica
    theta_rk4.append(r[0])
    omega_rk4.append(r[1])
    r += passo_rk4(f,r,t,h)

theta_exato = []
Omega = sqrt(g/L)
a = theta_0
b = omega_0 / Omega
for t in t_rk4:
    theta_exato.append(a*cos(Omega*t)+b*sin(Omega*t))
    
plt.figure(figsize=(12,9))
plt.plot(t_rk4,theta_rk4,t_rk4,omega_rk4)
plt.xlabel("t")
plt.ylabel("theta(t), omega(t)")
plt.show()

plt.figure(figsize=(12,9))
plt.plot(t_rk4,theta_rk4,t_rk4,theta_exato,'r.')
plt.xlabel("t")
plt.ylabel("theta(t)")
plt.show()
