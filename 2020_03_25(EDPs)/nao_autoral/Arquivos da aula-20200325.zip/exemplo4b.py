from math import cos
from numpy import arange,array,empty,zeros
from vpython import sphere,helix,color,rate,vector,scene

# Constantes
m = 1.0        # Massa de cada bolinha
k = 6.0        # Constante de mola
omega = 2.0    # Frequência angular da força externa
F_ext = 1.0    # Amplitude da força externa
N = 5          # Número de bolinhas
d = 3.0        # Distância de equilíbrio entre as bolinhas

# Condições iniciais
r_0 = zeros(2*N)  # Todas as bolinhas em repouso no equilíbrio

def f(r,t):
    x, v, ff = empty(N), empty(N), empty(2*N)
    for i in range(N):
        x[i], v[i] = r[2*i], r[2*i+1]
    ff[0], ff[1] = v[0], (k*(x[1]-x[0]) + F_ext*cos(omega*t))/m
    for i in range(1,N-1):
        ff[2*i], ff[2*i+1] = v[i], k*(x[i+1]-2*x[i]+x[i-1])/m
    ff[2*N-2], ff[2*N-1] = v[N-1], k*(x[N-2]-x[N-1])/m
    return ff

def passo_rk4(f,r,t,h):            # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0

a = 0.0             # Início do intervalo da variável independente
b = 200.0           # Final do intervalo da variável independente
N_passos = 10000    # Número de passos da integração numérica
h = (b-a)/N_passos  # Tamanho de um passo dessa solução

t_rk4 = arange(a,b,h)

# Definindo objetos para representar as bolinhas e as molas em VPython
bolinha = empty(N,sphere)
mola = empty(N-1,helix)
for i in range(N-1):
    mola[i] = helix(color=color.yellow,radius=0.5) 
    bolinha[i] = sphere(color=color.red)
bolinha[N-1] = sphere(color=color.red)
# Também vamos acompanhar o movimento do centro de massa, usando uma
# bolinha verde acima das demais para representá-lo
ycm = 3.0
cm = sphere(color=color.green,pos=vector(d*(N-1)/2,ycm,0))
# Ajustando a visualização
scene.center = vector(d*(N-1)/2,0,0)
scene.range = 0.5*N*d

r = r_0
for t in t_rk4:   # Realizando a integração numérica
    rate(200)
    xcm = 0.0
    for i in range(N-1):
        mola[i].pos = vector(d*i+r[2*i],0,0)
        mola[i].axis = vector(d+r[2*i+2]-r[2*i],0,0)
        bolinha[i].pos = vector(d*i+r[2*i],0,0)
        xcm += d*i+r[2*i]
    bolinha[N-1].pos = vector(d*(N-1)+r[2*N-2],0,0)
    xcm += d*(N-1)+r[2*N-2]
    xcm /= N
    cm.pos = vector(xcm,ycm,0)
    r += passo_rk4(f,r,t,h)
    

