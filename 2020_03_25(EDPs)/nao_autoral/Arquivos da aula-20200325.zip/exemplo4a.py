from math import cos
from numpy import arange,array,empty,zeros
import matplotlib.pyplot as plt

# Parâmetros da exibição dos gráficos
plt.rcParams['xtick.labelsize'] = 24
plt.rcParams['ytick.labelsize'] = 24
plt.rcParams['axes.labelsize'] = 28

# Constantes
m = 1.0        # Massa de cada bolinha
k = 6.0        # Constante de mola
omega = 2.0    # Frequência angular da força externa
F_ext = 1.0    # Amplitude da força externa
N = 5          # Número de bolinhas

# Condições iniciais
r_0 = zeros(2*N)  # Todas as bolinhas em repouso no equilíbrio

def f(r,t):
    x, v, ff = empty(N), empty(N), empty(2*N)
    for i in range(N):
        x[i], v[i] = r[2*i], r[2*i+1]
    ff[0], ff[1] = v[0], (k*(x[1]-x[0]) + F_ext * cos(omega*t))/m
    for i in range(1,N-1):
        ff[2*i], ff[2*i+1] = v[i], k*(x[i+1]-2*x[i]+x[i-1])/m
    ff[2*N-2], ff[2*N-1] = v[N-1], k*(x[N-2]-x[N-1])/m
    return ff

def passo_rk4(f,r,t,h):            # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0

a = 0.0             # Início do intervalo da variável independente
b = 10.0            # Final do intervalo da variável independente
N_passos = 2000     # Número de passos da integração numérica
h = (b-a)/N_passos  # Tamanho de um passo dessa solução

t_rk4 = arange(a,b,h)
x_rk4 = [[] for i in range(N)]  # Guardamos as posições em uma lista de listas

r = r_0
for t in t_rk4:   # Realizando a integração numérica
    for i in range(N):
        x_rk4[i].append(r[2*i]) # Registramos a posição de cada bolinha
    r += passo_rk4(f,r,t,h)
    
plt.figure(figsize=(12,9))
for i in range(N):
    plt.plot(t_rk4,x_rk4[i])
plt.xlabel("t")
plt.ylabel("xi(t)")
plt.show()

