from math import sqrt
from numpy import arange,array
import matplotlib.pyplot as plt

# Parâmetros da exibição dos gráficos
plt.rcParams['xtick.labelsize'] = 24
plt.rcParams['ytick.labelsize'] = 24
plt.rcParams['axes.labelsize'] = 28

# Constantes
G = 1.0     # Constante gravitacional em unidades arbitrárias
M = 10.0    # Massa da barra
L = 2.0     # Comprimento da barra

# Condições iniciais
x_0, y_0 = 1.0, 0.0     # Posição inicial
vx_0, vy_0 = 0.0, 1.0   # Velocidade inicial

GM, L24 = G*M, L**2/4
def f(r,t):
    x, vx, y, vy = r[0], r[1], r[2], r[3]
    rho2 = x**2 + y**2
    fator = GM/(rho2*sqrt(rho2+L24))
    f0, f1, f2, f3 = vx, -x*fator, vy, -y*fator
    return array([f0,f1,f2,f3],float)

def passo_rk4(f,r,t,h):            # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0

a = 0.0           # Início do intervalo da variável independente
b = 10.0          # Final do intervalo da variável independente
N = 1000          # Número de passos da integração numérica
h = (b-a)/N       # Tamanho de um passo dessa solução

t_rk4 = arange(a,b,h)
x_rk4, y_rk4 = [], []

r_0 = array([x_0,vx_0,y_0,vy_0],float)
r = r_0
for t in t_rk4:   # Realizando a integração numérica
    x_rk4.append(r[0])        # Registramos a coordenada x da posição
    y_rk4.append(r[2])        # Registramos a coordenada y da posição
    r += passo_rk4(f,r,t,h)
    
plt.figure(figsize=(12,9))
plt.plot(x_rk4,y_rk4)
plt.xlabel("x(t)")
plt.ylabel("y(t)")
plt.show()

