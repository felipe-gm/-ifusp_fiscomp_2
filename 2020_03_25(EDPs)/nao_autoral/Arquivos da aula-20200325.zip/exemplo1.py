from math import sin,cos,exp,sqrt,log
from numpy import arange,array
import matplotlib.pyplot as plt

# Parâmetros da exibição dos gráficos
plt.rcParams['xtick.labelsize'] = 24
plt.rcParams['ytick.labelsize'] = 24
plt.rcParams['axes.labelsize'] = 28

def f(r,t):
    x, y = r[0], r[1]
    fx, fy = x*y - x, y - x*y + sin(t)**2
    return array([fx,fy],float)

def passo_rk4(f,r,t,h):            # Calcula um passo no método de RK4
    k1 = h*f(r,t)
    k2 = h*f(r+0.5*k1,t+0.5*h)
    k3 = h*f(r+0.5*k2,t+0.5*h)
    k4 = h*f(r+k3,t+h)
    return (k1+2.0*(k2+k3)+k4)/6.0

a = 0.0           # Início do intervalo da variável independente
b = 10.0          # Final do intervalo da variável independente
N = 1000          # Número de passos da integração numérica
h = (b-a)/N       # Tamanho de um passo dessa solução

t_rk4 = arange(a,b,h)
x_rk4, y_rk4 = [], []
    
ra = array([1.0,1.0],float)          # Condição inicial, ou seja, r(a)
r = ra

for t in t_rk4:   # Realizando a integração numérica
    x_rk4.append(r[0])
    y_rk4.append(r[1])
    r += passo_rk4(f,r,t,h)
        
plt.figure(figsize=(12,9))
plt.plot(t_rk4,x_rk4,t_rk4,y_rk4)
plt.xlabel("t")
plt.ylabel("x(t), y(t)")
plt.show()

